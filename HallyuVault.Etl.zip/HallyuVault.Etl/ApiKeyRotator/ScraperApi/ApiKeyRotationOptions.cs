﻿namespace HallyuVault.Etl.ApiKeyRotator.ScraperApi
{
    public class ApiKeyRotationOptions
    {
        public List<string> ApiKeys { get; set; }
    }

}
