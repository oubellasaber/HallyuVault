﻿using HallyuVault.Core.Abstractions;
using HallyuVault.Etl.DramaDayMediaParser;
using HallyuVault.Etl.Fetcher;
using HallyuVault.Etl.FileCryptExtractor;
using HallyuVault.Etl.FileCryptExtractor.Entities.FileCryptContainer;
using HallyuVault.Etl.FileCryptExtractor.Entities.Rows;
using HallyuVault.Etl.Infra;
using HallyuVault.Etl.LinkResolving;
using HallyuVault.Etl.Orchestration.Entities;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics;
using System.Threading.Tasks.Dataflow;

namespace HallyuVault.Etl.Orchestration
{
    public class EtlOrchestrator
    {
        private readonly BufferBlock<DramaPost> _pipelineHead;
        DataflowLinkOptions Propagate = new DataflowLinkOptions { PropagateCompletion = true };

        public ITargetBlock<DramaPost> Entry => _pipelineHead;

        public EtlOrchestrator(IServiceProvider sp, CancellationToken token)
        {
            _pipelineHead = new BufferBlock<DramaPost>();

            var dramaPostRepository = sp.GetRequiredService<IDramaPostRepository>();

            var gateway = new ActionBlock<DramaPost>(async post =>
            {
                var dramaPost = await dramaPostRepository.GetAsync(post.DramaId);
                if (dramaPost == null)
                    await newMediaBlock.SendAsync(post);
                else
                    await partialUpdateBlock.SendAsync(post);
            });

            _pipelineHead.LinkTo(gateway, Propagate);

            // 🔷 NEW MEDIA WORKFLOW
            var htmlToMedia = new TransformBlock<DramaPost, Media>(async post =>
            {
                var parser = sp.GetRequiredService<MediaParser>();
                var result = await parser.Parse(post);
                // handle result, log unhandled drama posts
                return result.Value;
            });

            var saveMedia = new TransformBlock<Media, Media>(async media =>
            {
                var ctx = sp.GetRequiredService<EtlDbContext>();
                await ctx.AddAsync(media);
                await ctx.SaveChangesAsync(token);
                return media;
            });

            var broadcast = new BroadcastBlock<Media>(media => media);

            // genral metadat drama enrichement
            //var enrichMeta = new ActionBlock<Media>(async media =>
            //{
            //    var enricher = sp.GetRequiredService<IMetadataEnricher>();
            //    await enricher.EnrichAsync(media);
            //});

            var explode = new TransformManyBlock<Media, ResolvableEpisode>(media =>
            {
                return media.Seasons
                .SelectMany(season =>
                    // …for each mediaVersion in that season…
                    season.MediaVersions.SelectMany(mediaVersion =>
                        // …for each episode in that mediaVersion…
                        mediaVersion.Episodes.SelectMany(episode =>
                            // …for each EpisodeVersion in that episode…
                            episode.EpisodeVersions.SelectMany(version =>
                                // …project into an EpisodeRecord, now that you still have season and mediaVersion in scope
                                version.Links.Select(link =>
                                {
                                    return new ResolvableEpisode(season, mediaVersion, episode, version, link);
                                }
                            )
                        )
                    )
                ));
            });

            var resolveLinks = new TransformBlock<ResolvableEpisode, Result<ResolvableEpisode>>(async resolvableEpisode =>
            {
                bool isSuccess = false;
                var resolver = sp.GetRequiredService<ILinkResolver>();

                foreach (var link in resolvableEpisode.Links)
                {
                    var resolutionResult = await resolver.ResolveAsync(link.Url.ToString());

                    if (resolutionResult.IsSuccess)
                    {
                        isSuccess = true;
                    }
                }

                if (isSuccess)
                {
                    return resolvableEpisode;
                }
                else
                {
                    return Result.Failure<ResolvableEpisode>(new Error("LinkResolutionFailed", "Failed to resolve any links"));
                }
            });

            var broadcastLinks = new BroadcastBlock<ResolvableEpisode>(resolvableEpisode => resolvableEpisode);

            // save to db, add a filter only resolved links
            var saveLinks = new ActionBlock<ResolvableEpisode>(async resolvableEpisode =>
            {

            });

            // filter for filecrypt
            // what wpuld happen for ranged without a filecrypt link ??
            var extractContainerizedEpisodes = new TransformBlock<ResolvableEpisode, FileCryptContainer>(async resolvableEpisode =>
            {
                var filecryptLink = resolvableEpisode.Links.FirstOrDefault(link => link.Url.Host.Contains("filecrypt"));
                Debug.Assert(filecryptLink is not null, "the filter should have already verfied that we have at least one filecrypt link");

                var extractor = sp.GetRequiredService<FileCryptParsingService>();
                var container = await extractor.ParseAsync(filecryptLink.Url);

                // Handle it, when resolution fails, or either pass it downstream so it gets saved to the right table
                return container.Value;
            });

            var saveFileCryptContainer = new ActionBlock<ResolvableEpisode>(async resolvableEpisode =>
            {

            });

            // link grouping
            var groupLinks = new TransformBlock<FileCryptContainer, Dictionary<string, List<Row>>>(container =>
            {
                return new();
            });
        }

        private void RegisterGateway(IServiceProvider sp, CancellationToken token)
        {
            var dramaPostRepository = sp.GetRequiredService<IDramaPostRepository>();

            var gatewayBlock = new ActionBlock<DramaPost>(async dramaPost =>
            {
                // Fetch the drama post from the repository
                var fetchedDramaPost = await dramaPostRepository.GetAsync(dramaPost.DramaId);

                if (fetchedDramaPost == null)
                {
                    // Send to new 
                }
                else
                {
                    // send to old
                }
            });
        }

        private

        //private TransformBlock<DramaPost, Media> RegisterFullMediaScrapeWorkflow(IServiceProvider sp, CancellationToken token)
        //{
        //    var mediaParser = sp.GetRequiredService<MediaParser>();
        //    var dbCtx = sp.GetRequiredService<EtlDbContext>();

        //    var mediaParsingBlock = new TransformBlock<DramaPost, Media>(async dramaPost =>
        //    {
        //        // ToDo, use interfaces, IMediaParser .e.x
        //        Media media = mediaParser.Parse(dramaPost);

        //        return media;
        //    });

        //    var uploadMediaBlock = new ActionBlock<Media>(async media =>
        //    {
        //        // Upload media to the database
        //        await dbCtx.Medias.AddAsync(media);
        //        await dbCtx.SaveChangesAsync();
        //    });


        //}

        private ITargetBlock<DramaPost> RegisterFullMediaScrapeWorkflow(IServiceProvider sp, CancellationToken token)
        {
            var mediaParser = sp.GetRequiredService<MediaParser>();
            var dbCtx = sp.GetRequiredService<EtlDbContext>();

            // 1) Parse the HTML into a Media object
            var parseBlock = new TransformBlock<DramaPost, Media>(dramaPost =>
            {
                return Task.FromResult(mediaParser.Parse(dramaPost));
            });

            // 2) Save the Media and return it (so Ids are populated)
            var saveBlock = new TransformBlock<Media, Media>(async media =>
            {
                await dbCtx.Medias.AddAsync(media, token);
                await dbCtx.SaveChangesAsync(token);
                return media;
            });

            // 3) Broadcast the saved Media to multiple downstream blocks
            var broadcaster = new BroadcastBlock<Media>(m => m);

            // 4a) Metadata enrichment branch
            //var enrichMetaBlock = new ActionBlock<Media>(async media =>
            //{
            //    // media.Id is available here
            //    var tmdbId = await sp.GetRequiredService<IMetadataService>()
            //                        .EnrichAsync(media);
            //    media.TmdbId = tmdbId;
            //    await dbCtx.SaveChangesAsync(token);
            //});

            // 4b) Episode‐explosion branch
            var explodeBlock = new TransformManyBlock<Media, object>(media =>
                {
                    return media.Seasons
                    .SelectMany(season =>
                        // …for each mediaVersion in that season…
                        season.MediaVersions.SelectMany(mediaVersion =>
                            // …for each episode in that mediaVersion…
                            mediaVersion.Episodes.SelectMany(episode =>
                                // …for each EpisodeVersion in that episode…
                                episode.EpisodeVersions.Select(version =>
                                    // …project into an EpisodeRecord, now that you still have season and mediaVersion in scope
                                    (
                                        media.Id,
                                        season.SeasonNumber,
                                        mediaVersion.Name,
                                        GetEpisodeType(version),
                                        EpisodeRange = $"{version.StartRange}-{version.EndRange}",
                                        version
                                    )
                                )
                            )
                        )
                    );
                }
            );


            // 5) Link them all, once at startup


            parseBlock.LinkTo(saveBlock, _linkOpts);
            saveBlock.LinkTo(broadcaster, _linkOpts);

            broadcaster.LinkTo(explodeBlock, _linkOpts);

            // return the entry point of the pipeline
            return parseBlock;
        }

        public ITargetBlock<Media> RegisterLinkResolutionWorkflow(IServiceProvider sp, CancellationToken token)
        {

        }


        private TransformBlock<DramaPost, Media> RegisterPartialMediaUpdateWorkflow()
        {
            throw new NotImplementedException();
        }
    }
}


/*
 // ✅ THIS IS YOUR ETL PIPELINE COMPOSED ONCE AND REUSED

public class EtlPipeline
{
    private readonly BufferBlock<Post> _head;

    public ITargetBlock<Post> Entry => _head;

    public EtlPipeline(IServiceProvider sp, CancellationToken token)
    {
        _head = new BufferBlock<Post>();

        var gateway = new ActionBlock<Post>(async post =>
        {
            var repo = sp.GetRequiredService<IMediaRepository>();
            if (await repo.IsNewMediaAsync(post))
                await newMediaBlock.SendAsync(post);
            else
                await partialUpdateBlock.SendAsync(post);
        });

        _head.LinkTo(gateway, Propagate);

        // 🔷 NEW MEDIA WORKFLOW
        var htmlToMedia = new TransformBlock<Post, Media>(async post =>
        {
            var parser = sp.GetRequiredService<IHtmlParser>();
            var html = await parser.FetchHtmlAsync(post.Url);
            return parser.Parse(html);
        }, Options(token));

        var saveMedia = new TransformBlock<Media, Media>(async media =>
        {
            var db = sp.GetRequiredService<IMediaSaver>();
            return await db.SaveAndUpdateIdsAsync(media);
        }, Options(token));

        var broadcast = new BroadcastBlock<Media>(media => media);

        var enrichMeta = new ActionBlock<Media>(async media =>
        {
            var enricher = sp.GetRequiredService<IMetadataEnricher>();
            await enricher.EnrichAsync(media);
        }, Options(token));

        var explode = new TransformManyBlock<Media, EpisodeRecord>(media =>
        {
            var flattener = sp.GetRequiredService<IEpisodeFlattener>();
            return flattener.Flatten(media);
        }, Options(token));

        var resolveLinks = new TransformBlock<EpisodeRecord, EpisodeRecord>(async record =>
        {
            var resolver = sp.GetRequiredService<ILinkResolver>();
            return await resolver.ResolveAsync(record);
        }, Options(token));

        var saveLinks = new ActionBlock<EpisodeRecord>(async record =>
        {
            var db = sp.GetRequiredService<IResolvedLinkSaver>();
            await db.SaveAsync(record);
        }, Options(token));

        var renderedOnly = new TransformBlock<EpisodeRecord, EpisodeRecord>(record =>
        {
            return record.Type == EpisodeType.Rendered ? record : null;
        }, Options(token));

        var extractHtml = new ActionBlock<EpisodeRecord>(async record =>
        {
            var extractor = sp.GetRequiredService<IHtmlExtractor>();
            var uploader = sp.GetRequiredService<IUploader>();
            var html = await extractor.ExtractAsync(record);
            await uploader.UploadAsync(html);
        }, Options(token));

        // Wire NEW media pipeline
        htmlToMedia.LinkTo(saveMedia, Propagate);
        saveMedia.LinkTo(broadcast, Propagate);
        broadcast.LinkTo(enrichMeta, Propagate);
        broadcast.LinkTo(explode, Propagate);
        explode.LinkTo(resolveLinks, Propagate);
        resolveLinks.LinkTo(saveLinks, Propagate);
        saveLinks.LinkTo(renderedOnly, Propagate);
        renderedOnly.LinkTo(extractHtml, Propagate);

        newMediaBlock = htmlToMedia; // Head of the new media branch

        // 🔷 PARTIAL UPDATE WORKFLOW (stub for now)
        partialUpdateBlock = new ActionBlock<Post>(post => Task.CompletedTask);
    }

    private ITargetBlock<Post> newMediaBlock;
    private ITargetBlock<Post> partialUpdateBlock;

    private static readonly DataflowLinkOptions Propagate = new() { PropagateCompletion = true };

    private static ExecutionDataflowBlockOptions Options(CancellationToken token) =>
        new() { MaxDegreeOfParallelism = 4, BoundedCapacity = 100, CancellationToken = token };
}

 */