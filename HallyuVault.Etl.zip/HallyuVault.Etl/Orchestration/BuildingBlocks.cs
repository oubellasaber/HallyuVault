﻿using HallyuVault.Etl.DramaDayMediaParser;
using HallyuVault.Etl.DramaDayMediaParser.EpisodeParsing.StandardEpisodeParsing;
using HallyuVault.Etl.DramaDayMediaParser.EpisodeVersionsParsing;
using HallyuVault.Etl.Fetcher;
using System.Threading.Tasks.Dataflow;

namespace HallyuVault.Etl.Orchestration
{
    public class BuildingBlocks
    {
        public static BufferBlock<DramaPost> buffer = new BufferBlock<DramaPost>();

        public static TransformBlock<DramaPost, Media> HtmlTransformer = new TransformBlock<DramaPost, Media>(x => new Media("", "", ""));

        public static ActionBlock<Media> UploadMediaToDb = new ActionBlock<Media>(x =>
        {
            // Upload media to the database
            Console.WriteLine($"Uploading media to DB: {x}");
        });

        public static TransformManyBlock<Media, (int season, string mediaVersion, int epNumber, EpisodeVersion episodeVersion)> TransformManyBlock = new TransformManyBlock<Media, (int season, string mediaVersion, int epNumber, EpisodeVersion episodeVersion)>(media =>
        {
            // Transform media to episode versions
            var episodeVersions = new List<(int season, string mediaVersion, int epNumber, EpisodeVersion episodeVersion)>();

            foreach (var season in media.Seasons)
            {
                foreach (var mediaVersion in season.MediaVersions)
                {
                    foreach (var ep in mediaVersion.Episodes)
                    {
                        foreach (var item in ep.EpisodeVersions)
                        {
                            episodeVersions.Add((season.SeasonNumber ?? 1, mediaVersion.Name, ((StandardEpisode)ep).EpisodeNumber, item));
                        }
                    }
                }
            }
            return episodeVersions;
        });

        // resolution takes action

        // reoslved links get saved to db

        // after that passed to the next block

        public static void Execute(DramaPost dramaPost)
        {
            // Execute the transformation
            var media = HtmlTransformer.SendAsync(dramaPost).Result;

            // Do something with the transformed media
            Console.WriteLine($"Transformed Media: {media}");
        }
    }
}
