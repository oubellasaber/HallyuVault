﻿namespace HallyuVault.Etl.Orchestration.Entities
{
    public class ResolvableLink
    {
        private Uri? _resolvedUrl;

        public int Id { get; private set; }
        public string Host { get; private set; }
        public Uri Url { get; private set; }

        public ResolvableLink(int id, string host, Uri url)
        {
            Id = id;
            Host = host;
            Url = url;
        }

        public Uri? ResolvedLink => _resolvedUrl;

        public void SetResolvedLink(Uri resolvedLink)
        {
            if (resolvedLink == null)
            {
                throw new ArgumentNullException(nameof(resolvedLink), "Resolved link cannot be null.");
            }
            if (_resolvedUrl != null)
            {
                throw new InvalidOperationException("Resolved link has already been set.");
            }
            _resolvedUrl = resolvedLink;
        }

    }
}
