﻿using HallyuVault.Etl.DramaDayMediaParser.EpisodeParsing;
using HallyuVault.Etl.DramaDayMediaParser.EpisodeParsing.BatchEpisodeParsing;
using HallyuVault.Etl.DramaDayMediaParser.EpisodeParsing.SpecialEpisodeParsing;
using HallyuVault.Etl.DramaDayMediaParser.EpisodeParsing.StandardEpisodeParsing;
using HallyuVault.Etl.DramaDayMediaParser.EpisodeVersionsParsing;
using HallyuVault.Etl.DramaDayMediaParser.MediaVersionParsing;
using HallyuVault.Etl.DramaDayMediaParser.SeasonParsing;
using System.Diagnostics;

namespace HallyuVault.Etl.Orchestration.Entities
{
    public enum EpisodeType
    {
        Standard,
        Ranged,
        Special
    }

    public class ResolvableEpisode
    {
        public int SeasonNumber { get; }
        public string MediaVersionName { get; }
        public EpisodeType Type { get; }
        public Range? EpisodeRange { get; }
        public string EpisodeVersionName { get; }
        public IEnumerable<ResolvableLink> Links { get; }

        public ResolvableEpisode(
            int seasonNumber,
            string mediaVersionName,
            EpisodeType type,
            Range? episodeRange,
            string episodeVersionName,
            IEnumerable<ResolvableLink> links)
        {
            SeasonNumber = seasonNumber;
            MediaVersionName = mediaVersionName;
            Type = type;
            EpisodeRange = episodeRange;
            EpisodeVersionName = episodeVersionName;
            Links = links;
        }

        public ResolvableEpisode(
            Season season,
            MediaVersion mediaVersion,
            Episode episode,
            EpisodeVersion episodeVersion,
            DramaDayLink dramaDayLink)
        {
            SeasonNumber = season.SeasonNumber ?? 1;
            MediaVersionName = mediaVersion.Name;
            EpisodeVersionName = episodeVersion.Name;

            (EpisodeType, Range?) episodeInfo = episode switch
            {
                StandardEpisode standardEpisode => (EpisodeType.Standard, new Range(standardEpisode.EpisodeNumber, standardEpisode.EpisodeNumber)),
                BatchEpisode batchEpisode => (EpisodeType.Ranged, batchEpisode.EpisodeRange),
                SpecialEpisode specialEpisode => (EpisodeType.Special, null),
                _ => throw new UnreachableException($"Unknown episode type: {episode.GetType().Name}.")
            };

            (Type, EpisodeRange) = episodeInfo;
        }
    }
}
