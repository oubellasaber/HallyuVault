﻿using HallyuVault.Etl.Fetcher;

namespace HallyuVault.Etl.Orchestration
{
    public interface IDramaPostRepository
    {
        Task<DramaPost?> GetAsync(int dramaId);
        Task AddAsync(DramaPost media);
        Task AddBatchAsync(IEnumerable<DramaPost> media);
        Task<DateTime?> GetLastFetchedDramaPostUpdateDatetime();
    }
}