﻿using HallyuVault.Etl.Fetcher;
using HallyuVault.Etl.Orchestration;
using Quartz;
using System.Threading.Tasks.Dataflow;

namespace DramaDayFatcher.BackgroundJobs
{
    [DisallowConcurrentExecution]
    public class DramaFetchingBackgroundJob : IJob
    {
        private readonly IDramaPostRepository _dramaPostRepository;
        private readonly IDramaDayApiClient _dramaDayApiClient;
        private readonly ITargetBlock<DramaPost> _queue;

        public DramaFetchingBackgroundJob(
            IDramaPostRepository dramaPostRepository, 
            IDramaDayApiClient dramaDayApiClient,
            ITargetBlock<DramaPost> queue)
        {
            _dramaPostRepository = dramaPostRepository;
            _dramaDayApiClient = dramaDayApiClient;
            _queue = queue;
        }

        public async Task Execute(IJobExecutionContext context)
        {
            DateTime? lastFetchedDramaPostUpdateDatetime = await _dramaPostRepository.GetLastFetchedDramaPostUpdateDatetime();

            var posts = await _dramaDayApiClient.GetDramas(lastFetchedDramaPostUpdateDatetime);

            Console.WriteLine("Starting job");

            foreach (var post in posts)
            {
                await _queue.SendAsync(post);
            }

            // update the database with the last fetched post
        }
    }
}