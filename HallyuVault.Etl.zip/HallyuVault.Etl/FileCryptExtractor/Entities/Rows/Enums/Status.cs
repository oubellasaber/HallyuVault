﻿namespace HallyuVault.Etl.FileCryptExtractor.Entities.Rows.Enums;

public enum Status
{
    Online = 1,
    Offline = 2,
    Unknown = 3
}