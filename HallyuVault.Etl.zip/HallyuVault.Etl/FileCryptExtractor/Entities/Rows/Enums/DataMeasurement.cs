﻿namespace HallyuVault.Etl.FileCryptExtractor.Entities.Rows.Enums
{
    public enum DataMeasurement
    {
        MB = 1,
        GB = 2
    }
}
