﻿using System.Globalization;

namespace HallyuVault.Etl.FileCryptExtractor.Entities.FileCryptHeader;

public class FileCryptHeaderConfig
{
    public string DateFormat { get; set; }
}