﻿namespace HallyuVault.Etl.FileCryptExtractor.Entities.FileCryptHeader;

public class FileCryptSettings
{
    public Uri BaseUrl { get; set; }
    public string LinkEndpoint { get; set; }
}
