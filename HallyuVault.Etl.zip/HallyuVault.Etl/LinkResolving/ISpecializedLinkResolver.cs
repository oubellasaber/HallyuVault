﻿namespace HallyuVault.Etl.LinkResolving
{
    public interface ISpecializedLinkResolver : ILinkResolver
    {
    }
}
