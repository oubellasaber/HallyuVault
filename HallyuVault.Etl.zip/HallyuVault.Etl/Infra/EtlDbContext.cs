﻿using HallyuVault.Etl.DramaDayMediaParser;
using Microsoft.EntityFrameworkCore;

namespace HallyuVault.Etl.Infra
{
    // for the media
    public class EtlDbContext : DbContext
    {
        public DbSet<Media> Medias;

        public EtlDbContext(DbContextOptions<EtlDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            // Configure your entities here
        }
    }
}
