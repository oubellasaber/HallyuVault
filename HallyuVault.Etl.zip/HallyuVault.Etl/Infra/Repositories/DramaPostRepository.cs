﻿using HallyuVault.Etl.Fetcher;
using HallyuVault.Etl.Orchestration;

namespace HallyuVault.Etl.Infra.Repositories
{
    internal sealed class DramaPostRepository : IDramaPostRepository
    {
        private readonly EtlDbContext _context;

        public DramaPostRepository(EtlDbContext context)
        {
            _context = context;
        }

        public Task AddAsync(DramaPost media)
        {
            throw new NotImplementedException();
        }

        public Task AddBatchAsync(IEnumerable<DramaPost> media)
        {
            throw new NotImplementedException();
        }

        public Task<DateTime?> GetLastFetchedDramaPostUpdateDatetime()
        {
            throw new NotImplementedException();
        }
    }
}
