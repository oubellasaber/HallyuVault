﻿namespace HallyuVault.Etl.Fetcher
{
    public class FetchingOptions
    {
        public int Categories { get; set; }
        public string OrderBy { get; set; }
        public string Order { get; set; }
        public int PageSize { get; set; }
    }
}
