﻿using HallyuVault.Etl.DramaDayMediaParser.Abtractions;

namespace HallyuVault.Etl.DramaDayMediaParser.EpisodeParsing.UnknownEpisodeParsing
{
    public interface IUnknownEpisodeValidator : IHtmlNodeValidator;
}
