﻿using HallyuVault.Etl.DramaDayMediaParser.Abtractions;

namespace HallyuVault.Etl.DramaDayMediaParser.EpisodeParsing.SpecialEpisodeParsing
{
    internal interface ISpecialEpisodeValidator : IHtmlNodeValidator;
}
