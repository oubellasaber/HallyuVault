﻿using HallyuVault.Etl.DramaDayMediaParser.Abtractions;

namespace HallyuVault.Etl.DramaDayMediaParser.EpisodeParsing.StandardEpisodeParsing
{
    public interface IStandardEpisodeValidator : IHtmlNodeValidator;
}
