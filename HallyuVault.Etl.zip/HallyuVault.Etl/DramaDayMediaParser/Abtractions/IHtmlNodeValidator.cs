﻿using HallyuVault.Core.Abstractions;
using HtmlAgilityPack;

namespace HallyuVault.Etl.DramaDayMediaParser.Abtractions
{
    public interface IHtmlNodeValidator : IValidator<HtmlNode>;
}
