﻿using HallyuVault.Etl.DramaDayMediaParser.Abtractions;

namespace HallyuVault.Etl.DramaDayMediaParser.EpisodeVersionsParsing.TwoCellEpisodeVersion
{
    public interface ITwoCellEpisodeVersionValidator : IHtmlNodeValidator;
}
