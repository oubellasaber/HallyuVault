﻿using HallyuVault.Etl.DramaDayMediaParser.Abtractions;

namespace HallyuVault.Etl.DramaDayMediaParser.EpisodeVersionsParsing.ThreeCellEpisodeVersion
{
    public interface IThreeCellEpisodeVersionValidator : IHtmlNodeValidator;
}