﻿using HallyuVault.Etl.DramaDayMediaParser.Abtractions;

namespace HallyuVault.Etl.DramaDayMediaParser.EpisodeVersionsParsing.NoTableEpisodeVersion
{
    public interface INoTableEpisodeVersionValidator : IHtmlNodeValidator;
}
