﻿using HallyuVault.Etl.DramaDayMediaParser.Abtractions;

namespace HallyuVault.Etl.DramaDayMediaParser.SeasonParsing.UrlSeason
{
    public interface IUrlSeasonValidator : IHtmlNodeValidator
    {
    }
}
