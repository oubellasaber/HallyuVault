﻿using HallyuVault.Etl.DramaDayMediaParser.Abtractions;

namespace HallyuVault.Etl.DramaDayMediaParser.SeasonParsing.SidebarSeason
{
    public interface ISidebarSeasonValidator : IHtmlNodeValidator
    {
    }
}
