﻿using HallyuVault.Etl.DramaDayMediaParser.Abtractions;

namespace HallyuVault.Etl.DramaDayMediaParser.SeasonParsing.HorizontalSeason
{
    public interface IHorizontalSeasonValidator : IHtmlNodeValidator
    {
    }
}
