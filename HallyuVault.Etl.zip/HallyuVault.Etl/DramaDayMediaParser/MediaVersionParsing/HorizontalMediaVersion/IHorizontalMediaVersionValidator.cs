﻿using HallyuVault.Etl.DramaDayMediaParser.Abtractions;

namespace HallyuVault.Etl.DramaDayMediaParser.MediaVersionParsing.HorizontalMediaVersion
{
    public interface IHorizontalMediaVersionValidator : IHtmlNodeValidator;
}
