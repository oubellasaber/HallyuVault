﻿using HallyuVault.Etl.DramaDayMediaParser.Abtractions;

namespace HallyuVault.Etl.DramaDayMediaParser.MediaVersionParsing.SidebarMediaVersion
{
    public interface ISidebarMediaVersionValidator : IHtmlNodeValidator;
}
